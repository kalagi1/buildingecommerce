<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\FooterSlider;
use App\Models\Housing;
use App\Models\HousingFavorite;
use App\Models\HousingStatus;
use App\Models\HousingType;
use App\Models\HousingTypeParent;
use App\Models\Menu;
use App\Models\Offer;
use App\Models\Project;
use App\Models\Slider;
use App\Models\StandOutUser;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    public function index()
    {
        $menu = Menu::getMenuItems();
        $secondhandHousings = Housing::with('images')
            ->select(
                'housings.id',
                'housings.title AS housing_title',
                'housings.created_at',
                'housings.step1_slug',
                'housings.step2_slug',
                'housing_types.title as housing_type_title',
                'housings.housing_type_data',
                'project_list_items.column1_name as column1_name',
                'project_list_items.column2_name as column2_name',
                'project_list_items.column3_name as column3_name',
                'project_list_items.column4_name as column4_name',
                'project_list_items.column1_additional as column1_additional',
                'project_list_items.column2_additional as column2_additional',
                'project_list_items.column3_additional as column3_additional',
                'project_list_items.column4_additional as column4_additional',
                'housings.address',
                \Illuminate\Support\Facades\DB::raw('(SELECT cart FROM cart_orders WHERE JSON_EXTRACT(housing_type_data, "$.type") = "housings" AND JSON_EXTRACT(housing_type_data, "$.item.id") = housings.id) AS sold'),
                'cities.title AS city_title', // city tablosundan veri çekme
                'districts.ilce_title AS county_title' // district tablosundan veri çekme
            )
            ->leftJoin('housing_types', 'housing_types.id', '=', 'housings.housing_type_id')
            ->leftJoin('project_list_items', 'project_list_items.housing_type_id', '=', 'housings.housing_type_id')
            ->leftJoin('housing_status', 'housings.status_id', '=', 'housing_status.id')
            ->leftJoin('cities', 'cities.id', '=', 'housings.city_id') // city tablosunu join etme
            ->leftJoin('districts', 'districts.ilce_key', '=', 'housings.county_id') // district tablosunu join etme
            ->where('housings.status', 1)
            ->where('project_list_items.item_type', 2)
            ->orderByDesc('housings.created_at')
            ->get();
        $dashboardProjects = StandOutUser::where('start_date', "<=", date("Y-m-d"))->where('end_date', ">=", date("Y-m-d"))->orderBy("item_order")->get();
        $dashboardStatuses = HousingStatus::where('in_dashboard', 1)->orderBy("dashboard_order")->where("status", "1")->get();
        $brands = User::where("type", "2")->where("status", "1")->get();
        $sliders = Slider::all();
        $footerSlider = FooterSlider::all();
        $finishProjects = Project::with("city", "county")->whereHas('housingStatus', function ($query) {
            $query->where('housing_type_id', '2');
        })->with("housings", 'brand', 'roomInfo', 'housingType')->orderBy("created_at", "desc")->where('status', 1)->get();

        $continueProjects = Project::with("city", "county")->whereHas('housingStatus', function ($query) {
            $query->where('housing_type_id', '3');
        })->with("housings", 'brand', 'roomInfo', 'housingType')->where('status', 1)->orderBy("created_at", "desc")->get();

        $soilProjects = Project::with("city", "county")->whereHas('housingStatus', function ($query) {
            $query->where('housing_type_id', '5');
        })->with("housings", 'brand', 'roomInfo', 'housingType')->where('status', 1)->orderBy("created_at", "desc")->get();
        return view('client.home.index', compact('menu', "soilProjects", 'finishProjects', 'continueProjects', 'sliders', 'secondhandHousings', 'brands', 'dashboardProjects', 'dashboardStatuses', 'footerSlider'));
    }

    public function getRenderedProjects(Request $request)
    {

        $parameters = ["slug", "type", "optional", "title"];
        $secondhandHousings = [];
        $projects = [];
        $slug = [];
        $slugType = null;
        $slugName = [];

        $housingTypeSlug = [];
        $housingTypeSlugName = [];

        $housingType = [];
        $housingTypeName = [];

        $opt = null;
        $is_project = null;

        $optName = [];

        foreach ($parameters as $paramValue) {
            if ($paramValue) {
                if ($request->input($paramValue) == "satilik" || $request->input($paramValue) == "kiralik") {
                    $opt = $request->input($paramValue);
                    if ($opt) {
                        $opt = $opt;
                        if ($opt == "satilik") {
                            $optName = "Satılık";
                        } else {
                            $optName = "Kiralık";
                        }
                    }
                } else {
                    $item1 = HousingStatus::where('id', $request->input($paramValue))->first();
                    $housingTypeParent = HousingTypeParent::where('slug', $request->input($paramValue))->first();
                    $housingType = HousingType::where('slug', $request->input($paramValue))->first();

                    if ($item1) {
                        $slugName = $item1->name;
                        $slug = $item1->id;
                    }

                    if ($housingTypeParent) {
                        $housingTypeSlugName = $housingTypeParent->title;
                        $housingTypeSlug = $housingTypeParent->slug;
                    }

                    if ($housingType) {
                        $housingTypeName = $housingType->title;
                        $housingType = $housingType->id;
                    }
                }

            }
        }

        $query = Project::query()->where('status', 1);

        if ($request->input('city')) {
            $query->where('city_id', $request->input('city'));
        }

        if ($request->input('county')) {
            $query->where('county_id', $request->input('county'));
        }

        if ($request->input('filterDate')) {
            $filterDate = $request->input('filterDate');
        
            switch ($filterDate) {
                case 'last3Days':
                    $query->where('created_at', '>=', now()->subDays(3));
                    break;
        
                case 'lastWeek':
                    $query->where('created_at', '>=', now()->subWeek());
                    break;
        
                case 'lastMonth':
                    $query->where('created_at', '>=', now()->subMonth());
                    break;
        
        
                default:
                    break;
            }
        }
        
        if ($request->input('project_type')) {
            $slug = $request->input('project_type');
            $query->whereHas('housingTypes', function ($query) use ($slug) {
                $query->where('housing_type_id', $slug);
            });}

        if ($slug) {
            $query->whereHas('housingTypes', function ($query) use ($slug) {
                $query->where('housing_type_id', $slug);
            });
        }

        if ($housingTypeSlug) {
            $query->where("step1_slug", $housingTypeSlug);
        }

        if ($opt) {
            $query->where("step2_slug", $opt);
        }

        if ($housingType) {
            $query->where('housing_type_id', $housingType);
        }

        if ($request->input('neighborhood')) {
            $query->where('neighborhood_id', $request->input('neighborhood'));
        }

        // Sıralama seçeneğini kontrol et
        if ($request->input('sort')) {
            switch ($request->input('sort')) {
                case 'date-asc':
                    $query->orderBy('created_at', 'asc');
                    break;
                case 'date-desc':
                    $query->orderBy('created_at', 'desc');
                    break;
            }
        }

        $itemPerPage = 12;
        $projects = $query->paginate($itemPerPage);

        $renderedProjects = $projects->through(function ($item) {
            return [
                'image' => url(str_replace('public/', 'storage/', $item->image)),
                'url' => route('project.detail', $item->slug),
                "title" => $item->project_title,
            ];
        });

        return response()->json($renderedProjects);
    }

    public function getRenderedSecondhandHousings(Request $request)
    {

        function convertMonthToTurkishCharacter($date)
        {
            $aylar = [
                'January' => 'Ocak',
                'February' => 'Şubat',
                'March' => 'Mart',
                'April' => 'Nisan',
                'May' => 'Mayıs',
                'June' => 'Haziran',
                'July' => 'Temmuz',
                'August' => 'Ağustos',
                'September' => 'Eylül',
                'October' => 'Ekim',
                'November' => 'Kasım',
                'December' => 'Aralık',
                'Monday' => 'Pazartesi',
                'Tuesday' => 'Salı',
                'Wednesday' => 'Çarşamba',
                'Thursday' => 'Perşembe',
                'Friday' => 'Cuma',
                'Saturday' => 'Cumartesi',
                'Sunday' => 'Pazar',
                'Jan' => 'Oca',
                'Feb' => 'Şub',
                'Mar' => 'Mar',
                'Apr' => 'Nis',
                'May' => 'May',
                'Jun' => 'Haz',
                'Jul' => 'Tem',
                'Aug' => 'Ağu',
                'Sep' => 'Eyl',
                'Oct' => 'Eki',
                'Nov' => 'Kas',
                'Dec' => 'Ara',
            ];
            return strtr($date, $aylar);
        }

        function getData($housing, $key)
        {
            $housing_type_data = json_decode($housing->housing_type_data);
            $a = $housing_type_data->$key;
            return $a[0];
        }

        function getImage($housing, $key)
        {
            $housing_type_data = json_decode($housing->housing_type_data);
            $a = $housing_type_data->$key;
            return $a;
        }

        $parameters = ["slug", "type", "optional", "title"];
        $secondhandHousings = [];
        $projects = [];
        $slug = [];
        $slugName = [];

        $housingTypeSlug = [];
        $housingTypeSlugName = [];

        $housingType = [];
        $housingTypeName = [];

        $opt = null;
        $is_project = null;

        $optName = [];

        foreach ($parameters as $paramValue) {
            if ($paramValue) {
                if ($request->input($paramValue) == "satilik" || $request->input($paramValue) == "kiralik") {
                    $opt = $request->input($paramValue);
                    if ($opt) {
                        $opt = $opt;
                        if ($opt == "satilik") {
                            $optName = "Satılık";
                        } else {
                            $optName = "Kiralık";
                        }
                    }
                } else {
                    $item1 = HousingStatus::where('id', $request->input($paramValue))->first();
                    $housingTypeParent = HousingTypeParent::where('slug', $request->input($paramValue))->first();
                    $housingType = HousingType::where('slug', $request->input($paramValue))->first();

                    if ($item1) {
                        $is_project = $item1->is_project;
                        $slugName = $item1->name;
                        $slug = $item1->id;
                    }

                    if ($housingTypeParent) {
                        $housingTypeSlugName = $housingTypeParent->title;
                        $housingTypeSlug = $housingTypeParent->slug;
                    }

                    if ($housingType) {
                        $housingTypeName = $housingType->title;
                        $housingType = $housingType->id;
                    }
                }

            }
        }

        $obj = Housing::select('housings.*')->with('images', "city", "county")->where('housings.status', 1)->whereRaw('(SELECT 1 FROM cart_orders WHERE JSON_EXTRACT(cart, "$.type") = "housing" AND JSON_EXTRACT(cart, "$.item.id") = housings.id LIMIT 1) IS NULL');

        if ($housingTypeSlug) {
            $obj->where("step1_slug", $housingTypeSlug);
        }

        if ($housingType) {
            $obj->where('housing_type_id', $housingType);
        }

        if ($opt) {
            $obj->where('step2_slug', $opt);
        }

        if ($slug) {
            $obj->whereHas('housingStatus', function ($query) use ($slug) {
                $query->where('housing_status_id', $slug);
            });
        }

        if ($request->input('from_owner')) {
            switch ($request->input('from_owner')) {
                case 'from_owner':
                    $obj = $obj->join('users', 'users.id', '=', 'housings.user_id')
                        ->where('users.type', '1');
                    break;

                case 'from_office':
                    $obj = $obj->join('users', 'users.id', '=', 'housings.user_id')
                        ->join('user_plans', 'user_plans.user_id', '=', 'users.id')
                        ->join('subscription_plans', 'subscription_plans.id', '=', 'user_plans.subscription_plan_id')
                        ->where('users.type', '2')
                        ->where('subscription_plans.plan_type', 'Emlakçı');
                    break;

                case 'from_bank':
                    $obj = $obj->join('users', 'users.id', '=', 'housings.user_id')
                        ->join('user_plans', 'user_plans.user_id', '=', 'users.id')
                        ->join('subscription_plans', 'subscription_plans.id', '=', 'user_plans.subscription_plan_id')
                        ->where('users.type', '2')
                        ->where('subscription_plans.plan_type', 'Banka');
                    break;

                case 'from_company':
                    $obj = $obj->join('users', 'users.id', '=', 'housings.user_id')
                        ->join('user_plans', 'user_plans.user_id', '=', 'users.id')
                        ->join('subscription_plans', 'subscription_plans.id', '=', 'user_plans.subscription_plan_id')
                        ->where('users.type', '2')
                        ->where('subscription_plans.plan_type', 'İnşaat');
                    break;
            }
        }

        if ($request->input('city')) {
            $obj = $obj->where('city_id', $request->input('city'));
        }

        if ($request->input('county')) {
            $obj = $obj->where('county_id', $request->input('county'));
        }

        if ($request->input('neighborhood')) {
            $obj->where('neighborhood_id', $request->input('neighborhood'));
        }

        if ($request->input('price_min')) {
            $obj = $obj->whereRaw('CAST(JSON_UNQUOTE(JSON_EXTRACT(housing_type_data, "$.price[0]")) AS DECIMAL(10, 2)) >= ?', [$request->input('price_min')]);
        }

        if ($request->input('price_max')) {
            $obj = $obj->whereRaw('CAST(JSON_UNQUOTE(JSON_EXTRACT(housing_type_data, "$.price[0]")) AS DECIMAL(10, 2)) <= ?', [$request->input('price_max')]);
        }

        if ($request->input('msq_min')) {
            $obj = $obj->whereRaw('CAST(JSON_UNQUOTE(JSON_EXTRACT(housing_type_data, "$.squaremeters[0]")) AS DECIMAL(10, 2)) >= ?', [$request->input('msq_min')]);
        }

        if ($request->input('msq_max')) {
            $obj = $obj->whereRaw('CAST(JSON_UNQUOTE(JSON_EXTRACT(housing_type_data, "$.squaremeters[0]")) AS DECIMAL(10, 2)) <= ?', [$request->input('msq_max')]);
        }

        if ($request->input('room_count')) {
            $obj = $obj->whereJsonContains('housing_type_data->room_count', [$request->input('room_count')[0]]);
            $e = 0;
            foreach ($request->input('room_count') as $room_count) {
                if ($e == 0) {
                    $e = 1;
                    continue;
                }
                $obj = $obj->orWhereJsonContains('housing_type_data->room_count', [$room_count]);
            }
        }

        if ($request->input('post_date')) {
            switch ($request->input('post_date')) {
                case 'recent_day':
                    $obj = $obj->where('created_at', '>=', date('Y-m-d 00:00:00', strtotime('-1 Days')));
                    break;

                case 'last_3_day':
                    $obj = $obj->where('created_at', '>=', date('Y-m-d 00:00:00', strtotime('-3 Days')));
                    break;

                case 'last_7_day':
                    $obj = $obj->where('created_at', '>=', date('Y-m-d 00:00:00', strtotime('-7 Days')));
                    break;

                case 'last_15_day':
                    $obj = $obj->where('created_at', '>=', date('Y-m-d 00:00:00', strtotime('-15 Days')));
                    break;

                case 'last_30_day':
                    $obj = $obj->where('created_at', '>=', date('Y-m-d 00:00:00', strtotime('-30 Days')));
                    break;
            }
        }

        if ($request->input('sort')) {
            switch ($request->input('sort')) {
                case 'date-asc':
                    $obj = $obj->orderBy('created_at', 'asc');
                    break;
                case 'date-desc':
                    $obj = $obj->orderBy('created_at', 'desc');
                    break;
                case 'price-asc':
                    $obj = $obj->orderByRaw('CAST(JSON_UNQUOTE(JSON_EXTRACT(housing_type_data, "$.price[0]")) AS DECIMAL(10, 2)) ASC');
                    break;
                case 'price-desc':
                    $obj = $obj->orderByRaw('CAST(JSON_UNQUOTE(JSON_EXTRACT(housing_type_data, "$.price[0]")) AS DECIMAL(10, 2)) DESC');
                    break;
            }
        }

        $itemPerPage = 12;
        $obj = $obj->paginate($itemPerPage);

        return response()->json($obj->through(function ($item) use ($request) {
            $discount_amount = Offer::where('type', 'housing')->where('housing_id', $item->id)->where('start_date', '<=', date('Y-m-d H:i:s'))->where('end_date', '>=', date('Y-m-d Hi:i:s'))->first()->discount_amount ?? 0;
            $isFavorite = 0;
            if (Auth::check()) {
                $isFavorite = HousingFavorite::where("housing_id", $item->id)->where("user_id", Auth::user()->id)->first();
            }
            return [
                'image' => asset('housing_images/' . getImage($item, 'image')),
                'housing_type_title' => $item->housing_type_title,
                'id' => $item->id,
                'in_cart' => $request->session()->get('cart') && $request->session()->get('cart')['type'] == 'housing' && $request->session()->get('cart')['item']['id'] == $item->id,
                'is_favorite' => $isFavorite ? 1 : 0,
                'housing_url' => route('housing.show', $item->id),
                'title' => $item->title,
                'step1_slug' => $item->step1_slug,
                'housing_address' => $item->address,
                'city' => $item->city,
                'county' => $item->county,
                'created_at' => $item->created_at,
                'housing_type' =>
                [
                    'has_discount' => $discount_amount > 0,
                    'title' => $item->housing_type->title,
                    'room_count' => getData($item, 'room_count'),
                    'squaremeters' => getData($item, 'squaremeters'),
                    'price' => getData($item, 'price') - $discount_amount,
                    'housing_date' => date('j', strtotime($item->created_at)) . ' ' . convertMonthToTurkishCharacter(date('F', strtotime($item->created_at))),
                ],
            ];
        }));
    }

    public function getSearchList(Request $request)
    {
        $request->validate(
            [
                'searchTerm' => 'required|string',
            ]
        );

        $term = $request->input('searchTerm');

        return response()->json(
            [
                'project_housings' => [],
                'housings' => Housing::select('housings.*')
                    ->join('cities', 'cities.id', '=', 'housings.city_id')
                    ->join('counties', 'counties.id', '=', 'housings.county_id')
                    ->where('status', 1)
                    ->where(function ($query) use ($term) {
                        $query->where('housings.title', 'LIKE', "%{$term}%");
                        $query->orWhereRaw('JSON_EXTRACT(housings.housing_type_data, "$.room_count[0]") = ?', $term);
                        $query->orWhere('cities.title', $term);
                        $query->orWhere('counties.title', $term);
                    })
                    ->get()
                    ->map(function ($item) {
                        $housingData = json_decode($item->housing_type_data);
                        return [
                            'id' => $item->id,
                            'photo' => $housingData->image,
                            'name' => $item->title,
                        ];
                    }),
                'projects' => Project::where('project_title', 'LIKE', "%{$term}%")
                    ->where('status', 1)
                    ->get()->map(function ($item) {
                    return [
                        'id' => $item->id,
                        'photo' => $item->image,
                        'name' => $item->project_title,
                        'slug' => $item->slug,

                    ];
                }),
                'merchants' => User::where('type', '2')->where('name', 'LIKE', "%{$term}%")->get()->map(function ($item) {
                    return [
                        'id' => $item->id,
                        'photo' => $item->profile_image,
                        'name' => $item->name,
                        'slug' => Str::slug($item->name),
                    ];
                }),
            ]
        );
    }

}
