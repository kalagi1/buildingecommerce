@include('client.layouts.partials.header')

@yield('content')

@include('client.layouts.partials.footer')
