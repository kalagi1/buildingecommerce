@include('institutional.layouts.partials.header')

@yield('content')

@include('institutional.layouts.partials.footer')
