@include('admin.layouts.partials.header')

@yield('content')

@include('admin.layouts.partials.footer')